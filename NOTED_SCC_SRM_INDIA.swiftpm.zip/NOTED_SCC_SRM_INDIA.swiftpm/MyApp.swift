import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreen()
        }
    }
}

struct SplashScreen: View {
    @State private var isActive = false
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all) // Black background for contrast
            Image("noted") // Assuming the image name is "noted" from your upload
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                withAnimation {
                    isActive = true
                }
            }
        }
        .fullScreenCover(isPresented: $isActive) {
            OnboardingView()
        }
    }
}


